package com.thoughtworks;

import org.junit.Assert;
import org.junit.Test;

public class FirstTest {
    @Test
    public void setupShouldBeReady(){
        Assert.assertEquals(0, 0);
    }
  
}
